# redio2GT.africa Android App

Professional Android wrapper for the Timmy Tom Limited redio2GT.africa website.

Application ID: com.timmytom.redio2gt
Version: 1.0

The complete current website is bundled under:
app/src/main/assets/

Open the project in Android Studio and build an APK or Android App Bundle (AAB).
