const menu=document.querySelector('.menu');const links=document.querySelector('.links');if(menu)menu.addEventListener('click',()=>links.classList.toggle('open'));

const search=document.querySelector('#search'), category=document.querySelector('#category');
function filterProducts(){if(!search||!category)return;const q=search.value.toLowerCase(),c=category.value;document.querySelectorAll('.product').forEach(p=>{const okName=p.dataset.name.toLowerCase().includes(q),okCat=c==='all'||p.dataset.category===c;p.style.display=okName&&okCat?'block':'none'})}
if(search)search.addEventListener('input',filterProducts);if(category)category.addEventListener('change',filterProducts);

const form=document.querySelector('#orderForm');
if(form)form.addEventListener('submit',e=>{e.preventDefault();const name=document.querySelector('#name').value,phone=document.querySelector('#phone').value,product=document.querySelector('#product').value,qty=document.querySelector('#quantity').value,msg=document.querySelector('#message').value;const text=`Hello Timmy Tom Limited, I would like to place an order.%0A%0AName: ${encodeURIComponent(name)}%0APhone: ${encodeURIComponent(phone)}%0AProduct: ${encodeURIComponent(product)}%0AQuantity: ${encodeURIComponent(qty)}%0ADetails: ${encodeURIComponent(msg)}`;window.open(`https://wa.me/2348033293493?text=${text}`,'_blank')});
